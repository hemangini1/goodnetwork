<div id="mk-advanced-gmaps-<?php echo $id ?>" class="mk-advanced-gmaps <?php echo $class ?>  js-el" 
	style="<?php echo mk_insert_style( 'mk_advanced_gmap', $style ); ?>"
	data-mk-component='[ "AdvancedGMaps" <?php if( $full_height ) echo ', "FullHeight" ' ?>]'
	data-AdvancedGMaps-config='<?php echo $json ?>'
></div>