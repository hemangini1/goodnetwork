<?php
if (is_plugin_active('LayerSlider/layerslider.php')) {
    global $wpdb;
    $ls            = $wpdb->get_results("
      SELECT id, name, date_c
      FROM " . $wpdb->prefix . "layerslider
      WHERE flag_hidden = '0' AND flag_deleted = '0'
      ORDER BY date_c ASC LIMIT 999
      ");
    $layer_sliders = array();
    if ($ls) {
        foreach ($ls as $slider) {
            $layer_sliders[$slider->name] = $slider->id;
        }
    } else {
        $layer_sliders["No sliders found"] = 0;
    }
    vc_map(array(
        "name" => __("Layerslider", "mk_framework"),
        "base" => "mk_layerslider",
        'icon' => 'icon-mk-layerslider vc_mk_element-icon',
        "category" => __('Slideshows', 'mk_framework'),
        "params" => array(
            array(
                "type" => "dropdown",
                "heading" => __("Select Slideshow", "mk_framework"),
                "param_name" => "id",
                "value" => $layer_sliders,
                "description" => __("", "mk_framework")
            ),
            array(
                "type" => "textfield",
                "heading" => __("Extra class name", "mk_framework"),
                "param_name" => "el_class",
                "value" => "",
                "description" => __("If you wish to style particular content element differently, then use this field to add a class name and then refer to it in Custom CSS Shortcode or Masterkey Custom CSS option.", "mk_framework")
            )
        )
    ));
}
?>