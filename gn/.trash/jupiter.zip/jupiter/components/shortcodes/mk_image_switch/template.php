<div id="" class="mk-image-switch">
	<div class="image__container"></div>
</div>