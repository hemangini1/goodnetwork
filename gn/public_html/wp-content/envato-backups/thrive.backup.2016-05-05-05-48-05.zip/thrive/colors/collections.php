<?php

/**
 * Returns all the tags with classes and ids
 * that adapts primary colors.
 *
 * @return string The tags.
 */
function thrive_colors_tags( $type ) {

	$collection = array(

			'primary'   => '.primary, .site-content a, #page-sidenav-section a, #secondary-menu ul li a:hover,
					.user-notification-personal li a:hover, ul#notifications-ul li a:hover,
					.bp_docs #buddypress #bp-docs-all-docs li a:hover, .single-bp_doc #buddypress #bp-docs-all-docs li a:hover,
					.directory #buddypress #bp-docs-all-docs li a:hover, .buddypress #buddypress #bp-docs-all-docs li a:hover,
					.bp_docs #buddypress #bp-docs-all-docs li.current a, .single-bp_doc #buddypress #bp-docs-all-docs li.current a,
					.directory #buddypress #bp-docs-all-docs li.current a, .buddypress #buddypress #bp-docs-all-docs li.current a,
					.doc-tabs ul li:hover a, .doc-tabs ul li.current a, .tribe-events-list .type-tribe_events h2 a:hover,
					.bboss_search_page .search_filters ul li.current a, .bboss_search_page .search_filters ul li.active a,
					.bboss_search_page .search_filters ul li a:hover, #page-sidenav #page-sidebar-menu ul#secondary-menu-links .menu-item a:hover,
					#page-sidenav #page-sidebar-menu ul#secondary-menu-links .menu-item.current-menu-item a,
					.buddypress .pagination-links a.current, .buddypress .pagination-links span.current,
					.bp-user #item-body .profile ul.button-nav li.current a, .bp-user #item-body .profile ul.button-nav li a:hover,
					#item-nav ul li.current a, #item-nav ul li.current a#user-activity:before,
					#item-nav ul li.current a#user-xprofile:before, #item-nav ul li.current a#user-notifications:before,
					#item-nav ul li.current a#user-friends:before, #item-nav ul li.current a#user-groups:before,
					#item-nav ul li.current a#user-messages:before, #item-nav ul li.current a:before, .buddypress #subnav ul li.current a,
					.buddypress #subnav ul li a:hover, .buddypress .activity-type-tabs ul li.selected#activity-all a:before,
					.buddypress .activity-type-tabs ul li.selected#activity-groups a:before,
					.buddypress .activity-type-tabs ul li.selected#activity-mentions a:before,
					.buddypress .activity-type-tabs ul li.selected#activity-friends a:before,
					.buddypress .activity-type-tabs ul li.selected#activity-favorites a:before,
					.buddypress .activity-type-tabs ul li.selected#activity-notifications a:before,
					.buddypress .activity-type-tabs ul li.selected:before, .buddypress .activity-type-tabs ul li.selected a,
					.buddypress ul#activity-stream li .activity-meta a:hover,
					.buddypress ul#activity-stream li .activity-comments ul .acomment-context .acomment-options a:hover,
					.buddypress.directory.members .item-list-tabs ul li.selected a,
					.buddypress.directory.groups .item-list-tabs ul li.selected a,
					.group-create #group-create-tabs ul li.current a,
					body.thrive-layout-2_columns #sidebar-wrapper.dark #page-sidebar-menu #secondary-menu-links .menu-item.current-menu-item a, body.thrive-inline .expand_collapse a,
					body.thrive-inline #learndash_profile .expand_collapse a, body.thrive-inline #learndash_lessons a,
					body.thrive-inline .expand_collapse a, body.thrive-inline .learndash_topic_dots a, body.thrive-inline .learndash_topic_dots a > span, body.thrive-inline #learndash_lesson_topics_list span a, body.thrive-inline #learndash_profile a, body.thrive-inline #learndash_profile a span, .thrive-inline .rtmedia-container .rtm-media-options-list:hover, .thrive-inline .rtmedia-container .rtmedia-upload-media-link:hover, .thrive-inline ul.products li.product .price, .thrive-inline.woocommerce-page .products .product .price, .thrive-inline.woocommerce .products .product .price, .woocommerce div.product p.price, .woocommerce div.product span.price, .thrive-inline.woocommerce-page .star-rating, .thrive-inline.woocommerce .star-rating, .woocommerce .star-rating span, .woocommerce .star-rating:before, .thrive-inline .bbp-admin-links a:hover, .thrive-inline #bbpress-forums ul.bbp-replies .bbp-admin-links a:hover, .thrive-inline .bbp-reply-header a.bbp-reply-permalink, #tribe-events-content #tribe-events-footer a, .thrive-inline #bbpress-forums ul.bbp-replies
					.bbp-admin-links a:hover, .thrive-login-form .thrive-login-lost-password a, .thrive-login-form
					.login-remember label, .widget .item-options#friends-list-options a.selected,
					.widget .item-options#groups-list-options a.selected, .widget .item-options#members-list-options a.selected',
			'primary_shade' => '.bg-primary-700, #thrive_nav_wrap #site-navigation .sub-menu li.current-menu-item a, input[type=reset], input[type=button], input[type=submit], button, .button, #doc-submit-options .action.safe, .ac-reply-cancel, input[type=reset]:hover, input[type=button]:hover, input[type=submit]:hover, button:hover, .button:hover, #doc-submit-options .action.safe:hover, .ac-reply-cancel:hover, .thrive-inline.woocommerce-page ul.products li.product .onsale:before, .thrive-inline.woocommerce ul.products li.product .onsale:before, .thrive-inline.woocommerce-page div.product .onsale:before, .thrive-inline.woocommerce div.product .onsale:before,body.thrive-layout-2_columns #sidebar-wrapper #page-sidebar-toggle a#toggle-remove span.span-toggle, body.thrive-layout-2_columns a#toggle-add, #thrive-wisechat-support #thrive-wisechat-support-close-btn, body.thrive-inline .btn-blue, body.thrive-inline .learndash_checkout_button input[type="submit"], body.thrive-inline .wpProQuiz_button, body.thrive-inline .btn-join, body.thrive-inline #btn-join, body.thrive-inline a#quiz_continue_link, body.thrive-inline #learndash_back_to_lesson a, body.thrive-inline #learndash_next_prev_link a, body.thrive-inline #buddypress table#buddydrive-dir tr:last-child .buddydrive-load-more a, body.thrive a.delete-doc-button, .thrive-inline.woocommerce-page .products .product .button, .thrive-inline.woocommerce-page .products .product .button:hover, .thrive-inline.woocommerce-cart input.button, .thrive-inline.woocommerce-cart input.button:hover, .woocommerce input.button.alt, .woocommerce input.button.alt:hover, .thrive-inline.woocommerce-cart .wc-proceed-to-checkout a.checkout-button, .thrive-inline.woocommerce-cart .wc-proceed-to-checkout a.checkout-button:hover, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce input.button, .woocommerce #respond input#submit, .woocommerce #respond input#submit:hover, .woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce input.button:hover, .woocommerce div.product form.cart .button, .woocommerce div.product form.cart .button:hover, .woocommerce a.button.wc-backward, .woocommerce a.button.wc-backward:hover, .thrive-inline.woocommerce .products .product a.added_to_cart, body.thrive-inline.woocommerce .products .product a.added_to_cart:hover, .woocommerce .button.wc-forward, .woocommerce .button.wc-forward:hover, a.button.wc-forward, a.button.checkout.wc-forward, .thrive-inline .widget.widget_price_filter .price_slider_wrapper .ui-widget-content .ui-slider-range, .thrive-inline .widget.widget_price_filter .price_slider_wrapper .ui-widget-content .ui-slider-handle, .woocommerce .widget_price_filter .price_slider_amount .button, .woocommerce .widget_price_filter .price_slider_amount .button:hover, .thrive-inline .products .product .button, .thrive-inline .products .product .button:hover, .thrive-inline ul.products li.product .onsale:before, body.thrive-inline #tribe-events .tribe-events-button, body.thrive-inline #tribe-events .tribe-events-button:hover, body.thrive-inline #tribe-events .tribe-events-button:hover, body.thrive-inline .tribe-events-button, body.thrive-inline .tribe-events-button:hover, body.thrive-inline #tribe-bar-form .tribe-bar-submit input[type=submit], .tribe-events-calendar div[id*=tribe-events-daynum-], .tribe-events-calendar div[id*=tribe-events-daynum-] a, .widget.home-widgets h3.widget-title',
			'primary_background' => '.bg-primary, #thrive_nav #thrive_nav_wrap #site-navigation .sub-menu li a:hover, #thrive_footer_widget, .post-type-archive-tribe_events #content table.tribe-events-calendar tr th, .wp-polls .Buttons,body.thrive-layout-2_columns #sidebar-wrapper #page-sidebar-toggle a#toggle-remove, .thrive-inline .mfp-wrap .rtmedia-popup #rtm-modal-container .rtm-modal-title, .buddypress #wp-link-wrap.wp-core-ui #link-modal-title, .thrive-inline .tribe-events-cost, .thrive-inline #tribe-events-content .tribe-events-event-cost span, .single-tribe_events .tribe-events-schedule .tribe-events-cost, .tribe-events-calendar td.tribe-events-present div[id*=tribe-events-daynum-], .thrive-login-form .thrive-login-form__actions',
			'secondary' => '.secondary, .buddypress ul#activity-stream li .activity-meta a span, .buddypress ul#friends-list li .item-title span.update .activity-read-more a, .buddypress ul#members-list li .item-title span.update .activity-read-more a, .buddypress ul#friends-list li .item-title span.update .activity-read-more:after, .buddypress ul#members-list li .item-title span.update .activity-read-more:after, .buddypress ul#friends-list li .action a, .buddypress ul#members-list li .action a, .buddypress.directory.groups .item-list-tabs ul li a span, .buddypress ul#groups-list li .item-title span.update .activity-read-more a, .buddypress ul#groups-list li .item-title span.update .activity-read-more:after, .buddypress ul#groups-list li .action a, .single-item.groups .group-button.join-group, .single-item.groups .group-button.leave-group, .group-create #group-create-tabs ul li a, .group-create #group-create-tabs ul li span, .bp-user #item-header #item-buttons .generic-button a:hover',
			'secondary_background' => '.bg-secondary, .buddypress span.thrive-member-role, #message, .register-section #pass-strength-result.strong, #site-user-updates #navigation ul li .count, .buddypress .activity-type-tabs ul li a strong span, .buddypress ul#groups-list li .group-type, .single-item.groups #item-header #item-header-content .highlight, .thrive-inline p.demo_store',
			'borders_secondary' => '.buddypress #subnav ul li.selected.current a, .br-secondary, textarea:focus, input[type=text]:focus, input[type=email]:focus, input[type=number]:focus, input[type=url]:focus, input[type=password]:focus, input[type=search]:focus, input[name=s]:focus, .buddypress #subnav ul li a:hover, .buddypress.directory.members .item-list-tabs ul li.selected a'

		);

	return $collection[ $type ];
}
