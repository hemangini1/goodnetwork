<div class="mk-chart js-el" data-mk-component="Chart">
	<div class="mk-chart__chart"></div>
	<div class="mk-chart__desc"></div>
</div>